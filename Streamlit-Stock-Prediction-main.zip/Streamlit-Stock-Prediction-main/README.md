# Deep Learning Project Stock Prediction 

![streamlit](./readme-image.png)
```
streamlit run app.py 
```